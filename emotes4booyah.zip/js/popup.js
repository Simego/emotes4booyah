$('#openConfig').on('click', function(evt) {
    chrome.runtime.openOptionsPage();
})